$(document).ready(function() {
    $('#example').dataTable( {
 "language": {
            "url": "js/Spanish.json"
        },
        dom: 'Bfrtip',
        "scrollX": true,
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5'
        ],
    } );
} );

$(document).ready(function() {
    $('#example').dataTable( {
  "scrollX": true
} );
} );

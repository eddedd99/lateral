$(document).ready(function() {
    $('#example').DataTable( {
 "language": {
            "url": "js/Spanish.json"
        },
        dom: 'Bfrtip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5'
        ]
    } );
} );

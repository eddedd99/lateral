<?php
   require 'database.php';//1
   
  $id = null;
  if (!empty($_GET['id']))
      $id = $_REQUEST['id'];

  $regresar = "Location: clientes.php";
  if ( null==$id )
  header($regresar);

  //mostrar registro
  $pdo = Database::connect();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "SELECT" .
         " A.ID_CLIENTE " .
         ",A.RAZON_SOCIAL " .
         ",A.NOMBRE_CONTACTO " .
         ",A.TEL_PPAL " .
		 ",A.TEL_MOVIL " .
         "FROM CLIENTES A " .
         "WHERE A.ID_CLIENTE = ? ";
         
  $q = $pdo->prepare($sql);
  $q->execute(array($id));
  $data = $q->fetch(PDO::FETCH_ASSOC);
  
  // keep track post values
  $ID_CLIENTE = $data['ID_CLIENTE'];
  $inputRazonSocial = $data['RAZON_SOCIAL'];
  $inputNombreContacto = $data['NOMBRE_CONTACTO'];
  $inputTelPrincipal = $data['TEL_PPAL'];
  $inputTelMovil = $data['TEL_MOVIL'];
  
  Database::disconnect();
?>

<!DOCTYPE html>
<html lang="es-mx">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Ver Clientes</title>
  <!-- Bootstrap core CSS -->
  <!--<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">-->
  <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">-->
  <!-- Custom styles for this template -->
  <!--<link href="css/business-frontpage.css" rel="stylesheet">-->
  
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<body>
<br>

<div class="container-fluid">
<?php require 'menu.php'; ?>

<div class="col col-md-10">
  <form action="new_clientes.php" method="post">
  <h2>Visualizar Clientes</h2>
  <h5>Visualizar los datos del Cliente</h5>
  <br>
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputRazonSocial">Raz&oacute;n Social</label>
    <input type="text" class="form-control" id="inputRazonSocial" name="inputRazonSocial" placeholder="inputRazonSocial" value="<?php echo !empty($inputRazonSocial)?$inputRazonSocial:'';?>" readonly>
  </div>
  </div>
	
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputNombreContacto">Nombre del Contacto</label>
    <input type="text" class="form-control" id="inputNombreContacto" name="inputNombreContacto" placeholder="inputNombreContacto" value="<?php echo !empty($inputNombreContacto)?$inputNombreContacto:'';?>" readonly>
  </div>
  </div>
  
  <div class="form-row">
	<div class="form-group col-md-6">
       <label for="inputTelPrincipal">Tel&eacute;fono Principal</label>
       <input type="text" class="form-control" id="inputTelPrincipal" name="inputTelPrincipal" placeholder="inputTelPrincipal" value="<?php echo !empty($inputTelPrincipal)?$inputTelPrincipal:'';?>" readonly>
    </div>
	<div class="form-group col-md-6">
       <label for="inputTelMovil">Tel&eacute;fono M&oacute;vil</label>
       <input type="text" class="form-control" id="inputTelMovil" name="inputTelMovil" placeholder="inputTelMovil" value="<?php echo !empty($inputTelMovil)?$inputTelMovil:'';?>" readonly>
	</div>
  </div>
  <a href="clientes.php" class="btn btn-info">Regresar</a>
  </form>
</div>
</div>
</body>
</html>
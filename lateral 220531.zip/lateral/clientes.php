<?php
   require 'database.php';//1
?>

<!DOCTYPE html>
<html lang="es-MX">
<head>
  <title>Formulario</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css">
  
  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
  <script src="js/idioma_n_export.js"></script>
  <!--<script src="js/table_shown.js"></script>-->
</head>

<body>
<br>
<div class="container-fluid">
<?php require 'menu.php'; ?>

<div class="col col-md-10">
         <div class="row">
            <h3>Clientes</h3>
            <h5>Cat&aacute;logo de Clientes</h5>
         </div>
         
         <!--<div class="row">
               <a href="menu.php" class="btn btn-primary">Menu Principal</a>
               <a href="insert_administradores.php" class="btn btn-success">++ Nuevo</a>
         </div>-->
         
         <div class="row">
		 <table id="example" class="display nowrap compact cell-border" cellspacing="0" width="100%">
               <thead>
                  <tr>
                     <th>ID</th>
					 <th>Razon Social</th>
					 <th>Nombre Contacto</th>
                     <th>Tel Ppal</th>
					 <th>Tel Movil</th>
                     <th>Acciones</th>
                  </tr>
               </thead>
               <tbody>
                  <?php
                     $pdo = Database::connect();
                      $sql = 'SELECT' .
                             ' A.ID_CLIENTE ' .
                             ',A.RAZON_SOCIAL ' .
							 ',A.NOMBRE_CONTACTO ' .
							 ',A.TEL_PPAL ' .
							 ',A.TEL_MOVIL ' .
                             'FROM CLIENTES A ' .
                             'WHERE A.ID_CLIENTE > 0 ' .
                             'ORDER BY A.ID_CLIENTE ASC ';
                     
                      foreach ($pdo->query($sql) as $row) {
                        echo '<tr>';
                        echo '<td>'. $row['ID_CLIENTE'] . '</td>';
                        echo '<td>'. $row['RAZON_SOCIAL'] . '</td>';
						echo '<td>'. $row['NOMBRE_CONTACTO'] . '</td>';
                        echo '<td>'. $row['TEL_PPAL'] . '</td>';
						echo '<td>'. $row['TEL_MOVIL'] . '</td>';
                        echo '<td width="5%">';
                        echo '<div class="btn-group">';
                          echo '<button type="button" class="btn btn-info btn-sm dropdown-toggle" data-toggle="dropdown">Accion<span class="caret"></span></button>';
                          echo '<ul class="dropdown-menu" role="menu">';
                            echo '<li><a href="upd_clientes.php?id='.$row['ID_CLIENTE'].'">Actualizar</a></li>';
                            //echo '<li><a href="del_clientes.php?id='.$row['ID_CLIENTE'].'">Eliminar</a></li>';
                            echo '<li><a href="ver_clientes.php?id='.$row['ID_CLIENTE'].'">Visualizar</a></li>';
                            //echo '<li><a href="historia_clientes.php?id='.$row['ID_CLIENTE'].'">Historial</a></li>';
                            //echo '<li><a href="aprobacion_clientes.php?id='.$row['ID_CLIENTE'].'">Aprobar</a></li>';
                          echo '</ul>';
                        echo '</div>';
                        echo '</td>';
                        echo '</tr>';
                     }
                     
                     Database::disconnect();
                     ?>
               </tbody>
               <tfoot>
                  <tr>
                     <th>ID</th>
					 <th>Razon Social</th>
					 <th>Nombre Contacto</th>
                     <th>Tel Ppal</th>
					 <th>Tel Movil</th>
                     <th>Acciones</th>
                  </tr>
               </tfoot>
            </table>
         </div> <!--row-->
         <hr>
		</div> <!-- col col-md-10 -->
      </div><!-- container -->
   </body>
</html>
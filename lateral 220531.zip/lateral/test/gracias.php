<?php
    echo '<br>';
	echo '<h3>Gracias</h3>';
	echo '<h3><a href="altaclientes.php">Regresar a Formulario</a></h3>';
?>
<!DOCTYPE html>
<html lang="es-mx">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Formulario - Administraci&oacute;n de Ordenes de Servicio</title>
  <!-- Bootstrap core CSS -->
  <!--<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">-->
  <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">-->
  <!-- Custom styles for this template -->
  <!--<link href="css/business-frontpage.css" rel="stylesheet">-->
  
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<body>
<br>
<div class="container-fluid">
<div class="col col-md-2">			
						<div class="panel-group" id="accordion">
						  <div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="">
								Clientes</a>
							  </h4>
							</div>
							<div id="collapse1" class="panel-collapse collapse in">
								<ul class="list-group">
									<li class="list-group-item"><a href="formulario2a.php">Alta Cliente</a></li>
									<li class="list-group-item"><a href="formulario2b.php">Clientes</a></li>
									<li class="list-group-item"><a href="formulario2c.php">Reportes</a></li>
								</ul>
							</div>
						  </div>
						  <!--<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
								Blog</a>
							  </h4>
							</div>
							<div id="collapse2" class="panel-collapse collapse">
								<ul class="list-group">
									<li class="list-group-item"><span class="badge">12</span> New</li>
									<li class="list-group-item"><span class="badge">5</span> Deleted</li>
								</ul>
							</div>
						  </div>
							<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
								Settings</a>
							  </h4>
							</div>
							<div id="collapse3" class="panel-collapse collapse">
								<ul class="list-group">
									<li class="list-group-item"><span class="badge">1</span> Users Reported</li>
									<li class="list-group-item"><span class="badge">5</span> User Waiting Activation</li>
								</ul>
							</div>
						  </div>-->
						</div> 
</div>
<div class="col col-md-10">
<form>
  <h2>Formulario Clientes</h2>
  <h5>Capture los datos que se indican a continuaci&oacute;n</h5>
  <br>
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputRazonSocial">Raz&oacute;n Social</label>
    <input type="text" class="form-control" id="inputRazonSocial" placeholder="Indique la Raz&oacute;n Social">
    <!--<small id="inputRazonSocialayuda" class="text-muted">Indique la Raz&oacute;n Social de su empresa (Ej.Constructora Reyes, S.A.)</small>-->
  </div>
  </div>
	
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputNombreContacto">Nombre del Contacto</label>
    <input type="text" class="form-control" id="inputNombreContacto" placeholder="Indique el Nombre del Contacto">
    <!--<small id="inputNombreContactoayuda" class="text-muted">Indique Nombre del Contacto</small>-->
  </div>
  </div>
  
  <div class="form-row">
	<div class="form-group col-md-6">
       <label for="inputTelefonoPrincipal">Tel&eacute;fono Principal</label>
       <input type="text" class="form-control" id="inputTelefonoPrincipal" placeholder="Indique Telefono Principal">
       <!--<small id="inputTelefonoPrincipalayuda" class="text-muted">Indique Telefono Principal</small>-->
    </div>
	<div class="form-group col-md-6">
       <label for="inputTelefonoMovil">Tel&eacute;fono M&oacute;vil</label>
       <input type="text" class="form-control" id="inputTelefonoMovil" placeholder="Indique Telefono Movil">
       <!--<small id="inputTelefonoMovilayuda" class="text-muted">Indique Telefono Movil</small>-->
    </div>
  </div>

  <div class="form-row">
	<div class="form-group col-md-4">
       <label for="inputRFC">R.F.C.</label>
       <input type="text" class="form-control" id="inputRFC" placeholder="Indique R.F.C.">
       <!--<small id="inputRFC" class="text-muted">Indique R.F.C.</small>-->
    </div>
	<div class="form-group col-md-4">
       <label for="inputCURP">C.U.R.P.</label>
       <input type="text" class="form-control" id="inputCURP" placeholder="Indique C.U.R.P.">
       <!--<small id="inputCURP" class="text-muted">Indique C.U.R.P.</small>-->
    </div>
	<div class="form-group col-md-4">
       <label for="inputSPEI">CLABE Interbancaria (SPEI)</label>
       <input type="text" class="form-control" id="inputSPEI" placeholder="Indique CLABE Interbancaria (SPEI)">
       <!--<small id="inputSPEIayuda" class="text-muted">Indique CLABE Interbancaria</small>-->
    </div>
  </div>
  
  <div class="form-row">
  <div class="form-group col-md-4">
    <label for="inputTipo">Tipo de Cliente</label>
    <select id="inputTipo" class="form-control">
      <option selected>Seleccione...</option>
	  <option>Prospecto</option>
	  <option>Vigente</option>
    </select>
    <!--<small id="inputTipoayuda" class="text-muted">Seleccione Prospecto o Vigente</small>-->
  </div>
  <div class="form-group col-md-4">
    <label for="inputEstatus">Estatus</label>
    <select id="inputEstatus" class="form-control">
      <option selected>Seleccione...</option>
      <option>Activa</option>
	  <option>Inactiva</option>
    </select>
    <!--<small id="inputEstatusayuda" class="text-muted">Seleccione Activa o Inactiva</small>-->
  </div>
  <div class="form-group col-md-4">
    <label for="inputEstatus">Giro</label>
    <select id="inputEstatus" class="form-control">
      <option selected>Seleccione...</option>
      <option>Industrial</option>
	  <option>Comercial</option>
	  <option>Servicios</option>
    </select>
    <!--<small id="inputGiroayuda" class="text-muted">Seleccione Industrial,Comercial o Servicios</small>-->
  </div>
  </div>
  
  <div class="form-row">
    <div class="form-group col-md-4">
       <label for="inputFechaAlta">Fecha de Alta</label>
       <input type="date" class="form-control" id="inputFechaAlta" placeholder="Fecha de Alta">
       <!--<small id="inputFechaAltaayuda" class="text-muted">Indique Fecha de Alta del Cliente en nuestro sistema</small>-->
    </div>
	
	<div class="form-group col-md-4">
       <label for="inputComoNosConocio">C&oacute;mo nos conoci&oacute;?</label>
       <select id="inputComoNosConocio" class="form-control">
         <option selected>Seleccione...</option>
         <option>Internet</option>
	     <option>Referido</option>
		 <option>Prensa</option>
		 <option>Redes Sociales</option>
       </select>
    <!--<small id="inputComoNosConocioayuda" class="text-muted">Seleccione C&oacute;mo se enter&oacute; de nosotros</small>-->
    </div>
	
	<div class="form-group col-md-4">
       <label for="inputReferidoPor">Referido por?</label>
       <input type="text" class="form-control" id="inputReferidoPor" placeholder="Indique Nombre de quien refiere">
       <!--<small id="inputReferidoPorayuda" class="text-muted">Nombre de quien lo refiri&oacute;</small>-->
    </div>	
  </div>
  
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputAddress">Direcci&oacute;n</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
    <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
  </div>
  </div>

  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputAddress2">Direcci&oacute;n 2 (entrecalles, referencias)</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
    <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
  </div>
  </div>  
  
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">Ciudad</label>
      <input type="text" class="form-control" id="inputCity">
      <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Estado</label>
      <select id="inputState" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
      <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">C&oacute;digo Postal</label>
      <input type="text" class="form-control" id="inputZip">
      <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
    </div>
  </div>
  <div class="form-group col-md-12">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Enviarme Notificaciones
      </label>
      <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
    </div>
  </div>
  <button type="submit" class="btn btn-primary">Grabar</button>
</form>
<br>
<br>
</div>
</div>

</body>

</html>
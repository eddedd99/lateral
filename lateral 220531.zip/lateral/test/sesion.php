<?php
  session_start();
  
  //$_SESSION["nombre_user_session"] = '';
  $_SESSION['last_activity'] = time();
  $expire_time = 15*60; //15 mins

  if( $_SESSION['last_activity'] < time()-$expire_time ) {
    echo '<h3>La sesion ha expirado.</h3>';
    echo '<h3><a href="siacei.php">Ingrese nuevamente aqui</a></h3>';
    die();
    }
  else {
    $_SESSION['last_activity'] = time();
    }
?>

<?php
   require 'database.php';//1
   //require 'sesion.php';//2
   
   $r_actualizado=0;
   
if (!empty($_POST)) {

     // Validacion de campos
     $NOMBRE_CONTACTO = trim($_POST['inputNombreContacto']);
     $RAZON_SOCIAL = trim($_POST['inputRazonSocial']);
     $TEL_MOVIL = trim($_POST['inputTelMovil']);
     $TEL_PPAL = trim($_POST['inputTelPrincipal']);
     
	 //echo 'HOLA';
	 //echo $NOMBRE_CONTACTO;
     //exit();

     // validate input
     $valid = true;
                 
     //Insert data
     if ($valid) {
      
      require 'zona_horaria.php';
      
      //Si no hay sesion, asignar
      if (!isset($_SESSION["nombre_user_session"]))
         $id_usuario='0';
      else
         $id_usuario=trim($_SESSION["nombre_user_session"]);
      
      $pdo = Database::connect();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO CLIENTES (" .
                "RAZON_SOCIAL " .
                ",NOMBRE_CONTACTO" .
                ",TEL_PPAL" .
                ",TEL_MOVIL) " .
                "VALUES (?,?,?,?) ";
                               
      $q = $pdo->prepare($sql);
      
      if ($q->execute(array($RAZON_SOCIAL,$NOMBRE_CONTACTO,$TEL_PPAL,$TEL_MOVIL)))
          $r_actualizado=1;
      else
          $r_actualizado=0;
      
      Database::disconnect();
      header("Location: gracias.php");
      
      }//valid
      
    }//Post
?>

<!DOCTYPE html>
<html lang="es-mx">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Formulario</title>
  <!-- Bootstrap core CSS -->
  <!--<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">-->
  <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">-->
  <!-- Custom styles for this template -->
  <!--<link href="css/business-frontpage.css" rel="stylesheet">-->
  
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<body>
<br>
<form action="altaclientes.php" method="post">
<div class="container-fluid">
<div class="col col-md-2">
						<div class="panel-group" id="accordion">
						  <div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="">
								Clientes</a>
							  </h4>
							</div>
							<div id="collapse1" class="panel-collapse collapse in">
								<ul class="list-group">
									<li class="list-group-item"><a href="altaclientes.php">Alta Clientes</a></li>
									<li class="list-group-item"><a href="clientes.php">Clientes</a></li>
									<li class="list-group-item"><a href="reportes.php">Reportes</a></li>
								</ul>
							</div>
						  </div>
						  <!--<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
								Blog</a>
							  </h4>
							</div>
							<div id="collapse2" class="panel-collapse collapse">
								<ul class="list-group">
									<li class="list-group-item"><span class="badge">12</span> New</li>
									<li class="list-group-item"><span class="badge">5</span> Deleted</li>
								</ul>
							</div>
						  </div>
							<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
								Settings</a>
							  </h4>
							</div>
							<div id="collapse3" class="panel-collapse collapse">
								<ul class="list-group">
									<li class="list-group-item"><span class="badge">1</span> Users Reported</li>
									<li class="list-group-item"><span class="badge">5</span> User Waiting Activation</li>
								</ul>
							</div>
						  </div>-->
						</div> 
</div>

<div class="col col-md-10">
  <h2>Formulario Clientes</h2>
  <h5>Capture los datos que se indican a continuaci&oacute;n</h5>
  <br>
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputRazonSocial">Raz&oacute;n Social</label>
    <input type="text" class="form-control" name="inputRazonSocial" id="inputRazonSocial" placeholder="Indique la Raz&oacute;n Social" onkeyup="this.value = this.value.toUpperCase();" required>
    <!--<input type="text" class="form-control" name="inputRazonSocial" id="inputRazonSocial" placeholder="Indique la Raz&oacute;n Social" required oninvalid="this.setCustomValidity('Ingrese Razon Social')" 
 oninput="this.setCustomValidity('')"/>-->
    <!--<small id="inputRazonSocialayuda" class="text-muted">Indique la Raz&oacute;n Social de su empresa (Ej.Constructora Reyes, S.A.)</small>-->
  </div>
  </div>
	
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputNombreContacto">Nombre del Contacto</label>
    <input type="text" class="form-control" name="inputNombreContacto" id="inputNombreContacto" placeholder="Indique el Nombre del Contacto" required>
    <!--<small id="inputNombreContactoayuda" class="text-muted">Indique Nombre del Contacto</small>-->
  </div>
  </div>
  
  <div class="form-row">
	<div class="form-group col-md-6">
       <label for="inputTelPrincipal">Tel&eacute;fono Principal</label>
       <input type="tel" class="form-control" name="inputTelPrincipal" id="inputTelPrincipal" placeholder="Indique Telefono Principal" maxlength="50">
       <!--<small id="inputTelefonoPrincipalayuda" class="text-muted">Indique Telefono Principal</small>-->
    </div>
	<div class="form-group col-md-6">
       <label for="inputTelMovil">Tel&eacute;fono M&oacute;vil</label>
       <input type="tel" class="form-control" name="inputTelMovil" id="inputTelMovil" placeholder="Indique Telefono Movil">
       <!--<small id="inputTelefonoMovilayuda" class="text-muted">Indique Telefono Movil</small>-->
    </div>
  </div>

  <button type="submit" class="btn btn-primary">Grabar</button>
  <button type="reset" class="btn btn-secondary">Limpiar</button>
</form>

</div>
</div>
</body>
</html>

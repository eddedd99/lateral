<?php
   require 'database.php';//1
   require 'sesion.php';//2
   require 'menu_barra.php';//3
   
   $r_actualizado=0;
   
if (!empty($_POST)) {
     
     // Validacion de campos
     $RAZON_SOCIAL = trim($_POST['RAZON_SOCIAL']);
     $NOMBRE_CONTACTO = trim($_POST['NOMBRE_CONTACTO']);
     $TEL_PPAL = trim($_POST['TEL_PPAL']);
	 $TEL_MOVIL = trim($_POST['TEL_MOVIL']);
     
     // validate input
     $valid = true;
                 
     //Insert data
     if ($valid) {
      
      require 'zona_horaria.php';
      
      //Si no hay sesion, asignar
      if (!isset($_SESSION["nombre_user_session"]))
         $id_usuario='0';
      else
         $id_usuario=trim($_SESSION["nombre_user_session"]);
      
      $pdo = Database::connect();
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      $sql = "INSERT INTO CLIENTES (" .
                "R_LOCK " .
                ",NOMBRE_ADMIN" .
                ",CONTACTO" .
                ",ESTATUS" .
				",TIPO" .
				",FECHA_INI" .
				",FECHA_FIN" .
				",DEPTO" .
                ",COMENTARIOS" .
                ",USUARIO" .
				",FECHA_CREACION" .
                ",FECHA_ACTUALIZACION) " .
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ";
             
      $q = $pdo->prepare($sql);
      
      if ($q->execute(array('0',$NOMBRE_ADMIN,$CONTACTO,$ESTATUS,$TIPO,$FECHA_INI,$FECHA_FIN,$DEPTO,$COMENTARIOS,$id_usuario,$fecha_local_db,$fecha_local_db)))
          $r_actualizado=1;
      else
          $r_actualizado=0;
                           
      //�ltimo rec ingresado
      $stmt = $pdo->query("SELECT LAST_INSERT_ID()");
      $last_id = $stmt->fetchColumn();
                                      
      //Inserta en Bit�cora
      //$sql = "INSERT INTO ADMINISTRADORES_BITAC " .
      //       "(R_LOCK,ID_ADMIN,NOMBRE_ADMIN,CONTACTO,ESTATUS,FECHA_INI,FECHA_FIN,DEPTO,COMENTARIOS,USUARIO,FECHA_CREACION,FECHA_ACTUALIZACION) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      //$q = $pdo->prepare($sql);
      //$q->execute(array('0',$last_id,$NOMBRE_ADMIN,$CONTACTO,$ESTATUS,$FECHA_INI,$FECHA_FIN,$DEPTO,$COMENTARIOS,$USUARIO,$fecha_local_db,$fecha_local_db));
      
      Database::disconnect();
      header("Location: gracias.php");
      
      }//valid
      
    }//Post
?>

<!DOCTYPE html>
<html lang="es-MX">
<head>
  <title>Formulario</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>

<body>
<div class="container-fluid">
<div class="col col-md-2">
						<div class="panel-group" id="accordion">
						  <div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="">
								Clientes</a>
							  </h4>
							</div>
							<div id="collapse1" class="panel-collapse collapse in">
								<ul class="list-group">
									<li class="list-group-item"><a href="formulario2a.php">Alta Cliente</a></li>
									<li class="list-group-item"><a href="formulario2b.php">Clientes</a></li>
									<li class="list-group-item"><a href="formulario2c.php">Reportes</a></li>
								</ul>
							</div>
						  </div>
						  <!--<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
								Blog</a>
							  </h4>
							</div>
							<div id="collapse2" class="panel-collapse collapse">
								<ul class="list-group">
									<li class="list-group-item"><span class="badge">12</span> New</li>
									<li class="list-group-item"><span class="badge">5</span> Deleted</li>
								</ul>
							</div>
						  </div>
							<div class="panel panel-default">
							<div class="panel-heading">
							  <h4 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
								Settings</a>
							  </h4>
							</div>
							<div id="collapse3" class="panel-collapse collapse">
								<ul class="list-group">
									<li class="list-group-item"><span class="badge">1</span> Users Reported</li>
									<li class="list-group-item"><span class="badge">5</span> User Waiting Activation</li>
								</ul>
							</div>
						  </div>-->
						</div> 
</div>

<div class="col col-md-10">
<form action="insertar.php" method="post">
  <h2>Formulario Clientes</h2>
  <h5>Capture los datos que se indican a continuaci&oacute;n</h5>
  <br>
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputRazonSocial">Raz&oacute;n Social</label>
    <input type="text" class="form-control" id="inputRazonSocial" placeholder="Indique la Raz&oacute;n Social">
    <!--<small id="inputRazonSocialayuda" class="text-muted">Indique la Raz&oacute;n Social de su empresa (Ej.Constructora Reyes, S.A.)</small>-->
  </div>
  </div>
	
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputNombreContacto">Nombre del Contacto</label>
    <input type="text" class="form-control" id="inputNombreContacto" placeholder="Indique el Nombre del Contacto">
    <!--<small id="inputNombreContactoayuda" class="text-muted">Indique Nombre del Contacto</small>-->
  </div>
  </div>
  
  <div class="form-row">
	<div class="form-group col-md-6">
       <label for="inputTelefonoPrincipal">Tel&eacute;fono Principal</label>
       <input type="text" class="form-control" id="inputTelefonoPrincipal" placeholder="Indique Telefono Principal">
       <!--<small id="inputTelefonoPrincipalayuda" class="text-muted">Indique Telefono Principal</small>-->
    </div>
	<div class="form-group col-md-6">
       <label for="inputTelefonoMovil">Tel&eacute;fono M&oacute;vil</label>
       <input type="text" class="form-control" id="inputTelefonoMovil" placeholder="Indique Telefono Movil">
       <!--<small id="inputTelefonoMovilayuda" class="text-muted">Indique Telefono Movil</small>-->
    </div>
  </div>

  <div class="form-row">
	<div class="form-group col-md-4">
       <label for="inputRFC">R.F.C.</label>
       <input type="text" class="form-control" id="inputRFC" placeholder="Indique R.F.C.">
       <!--<small id="inputRFC" class="text-muted">Indique R.F.C.</small>-->
    </div>
	<div class="form-group col-md-4">
       <label for="inputCURP">C.U.R.P.</label>
       <input type="text" class="form-control" id="inputCURP" placeholder="Indique C.U.R.P.">
       <!--<small id="inputCURP" class="text-muted">Indique C.U.R.P.</small>-->
    </div>
	<div class="form-group col-md-4">
       <label for="inputSPEI">CLABE Interbancaria (SPEI)</label>
       <input type="text" class="form-control" id="inputSPEI" placeholder="Indique CLABE Interbancaria (SPEI)">
       <!--<small id="inputSPEIayuda" class="text-muted">Indique CLABE Interbancaria</small>-->
    </div>
  </div>
  
  <div class="form-row">
  <div class="form-group col-md-4">
    <label for="inputTipo">Tipo de Cliente</label>
    <select id="inputTipo" class="form-control">
      <option selected>Seleccione...</option>
	  <option>Prospecto</option>
	  <option>Vigente</option>
    </select>
    <!--<small id="inputTipoayuda" class="text-muted">Seleccione Prospecto o Vigente</small>-->
  </div>
  <div class="form-group col-md-4">
    <label for="inputEstatus">Estatus</label>
    <select id="inputEstatus" class="form-control">
      <option selected>Seleccione...</option>
      <option>Activa</option>
	  <option>Inactiva</option>
    </select>
    <!--<small id="inputEstatusayuda" class="text-muted">Seleccione Activa o Inactiva</small>-->
  </div>
  <div class="form-group col-md-4">
    <label for="inputEstatus">Giro</label>
    <select id="inputEstatus" class="form-control">
      <option selected>Seleccione...</option>
      <option>Industrial</option>
	  <option>Comercial</option>
	  <option>Servicios</option>
    </select>
    <!--<small id="inputGiroayuda" class="text-muted">Seleccione Industrial,Comercial o Servicios</small>-->
  </div>
  </div>
  
  <div class="form-row">
    <div class="form-group col-md-4">
       <label for="inputFechaAlta">Fecha de Alta</label>
       <input type="date" class="form-control" id="inputFechaAlta" placeholder="Fecha de Alta">
       <!--<small id="inputFechaAltaayuda" class="text-muted">Indique Fecha de Alta del Cliente en nuestro sistema</small>-->
    </div>
	
	<div class="form-group col-md-4">
       <label for="inputComoNosConocio">C&oacute;mo nos conoci&oacute;?</label>
       <select id="inputComoNosConocio" class="form-control">
         <option selected>Seleccione...</option>
         <option>Internet</option>
	     <option>Referido</option>
		 <option>Prensa</option>
		 <option>Redes Sociales</option>
       </select>
    <!--<small id="inputComoNosConocioayuda" class="text-muted">Seleccione C&oacute;mo se enter&oacute; de nosotros</small>-->
    </div>
	
	<div class="form-group col-md-4">
       <label for="inputReferidoPor">Referido por?</label>
       <input type="text" class="form-control" id="inputReferidoPor" placeholder="Indique Nombre de quien refiere">
       <!--<small id="inputReferidoPorayuda" class="text-muted">Nombre de quien lo refiri&oacute;</small>-->
    </div>	
  </div>
  
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputAddress">Direcci&oacute;n</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">
    <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
  </div>
  </div>

  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputAddress2">Direcci&oacute;n 2 (entrecalles, referencias)</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor">
    <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
  </div>
  </div>  
  
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">Ciudad</label>
      <input type="text" class="form-control" id="inputCity">
      <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">Estado</label>
      <select id="inputState" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
      <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">C&oacute;digo Postal</label>
      <input type="text" class="form-control" id="inputZip">
      <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
    </div>
  </div>
  <div class="form-group col-md-12">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Enviarme Notificaciones
      </label>
      <!--<small id="passwordHelpInline" class="text-muted">Must be 8-20 characters long.</small>-->
    </div>
  </div>
  <button type="submit" class="btn btn-primary">Grabar</button>
  <button type="reset" class="btn btn-secondary">Limpiar</button>
</form>
</div>
         <div class="row">
            <h3>Alta de Administradores</h3>
            <h5>Ingresar datos del Administrador</h5>
               <nav aria-label="breadcrumb">
                 <ol class="breadcrumb">
                   <li class="breadcrumb-item"><a href="administradores.php">Inicio</a></li>
                   <li class="breadcrumb-item active">Alta Administradores</li>
                 </ol>
               </nav>
         </div><!-- row -->

         <div class="row">
           <form action="insert_administradores.php" method="post">
                 <div class="form-group row">
                    <label for="NOMBRE_ADMIN" class="col-sm-2 col-form-label">Nombre Administrador:</label>
                    <div class="col-sm-8">
                      <input type="text" class="form-control" id="NOMBRE_ADMIN" name="NOMBRE_ADMIN" placeholder="Escriba Nombre Completo del Administrador" maxlength="100" size="100" required>
                    </div>
                 </div>
                 <div class="form-group row">
                    <label for="CONTACTO" class="col-sm-2 col-form-label">Contacto:</label>
                    <div class="col-sm-8">
                      <input type="text" class="form-control" id="CONTACTO" name="CONTACTO" placeholder="Escriba datos de contacto ej: tel celular, email, tel.domicilio." maxlength="60" size="60" required>
                    </div>
                 </div>
                 <div class="form-group row">
                    <label for="ESTATUS" class="col-sm-2 col-form-label">Estatus:</label>
                    <div class="col-sm-8">
                    <select class="form-control" id="ESTATUS" name="ESTATUS" required placeholder="Indicar el Estatus">
                      <option value="A">Activo</option>
                      <option value="H" selected>Historico</option>
                    </select>
                    </div>
                 </div><!--form group row-->
               <div class="form-group row">
                    <label for="TIPO" class="col-sm-2 col-form-label">Tipo:</label>
                    <div class="col-sm-8">
                    <select class="form-control" id="TIPO" name="TIPO" required placeholder="Indicar el Tipo de Administrador">
                      <option value="AC">Admin Condomino</option>
                      <option value="AP">Admin Profesional</option>
                    </select>
                    </div>
               </div><!--form group row-->
                 <div class="form-group row">
                    <label for="FECHA_INI" class="col-sm-2 col-form-label">Fecha Inicio:</label>
                    <div class="col-sm-8">
                      <input type="date" class="form-control" id="FECHA_INI" name="FECHA_INI" required placeholder="Escriba la Fecha Inicio de su Administraci&oacute;n" maxlength="12" size="12" required>
                    </div>
                 </div>
                 <div class="form-group row">
                    <label for="FECHA_FIN" class="col-sm-2 col-form-label">Fecha Fin:</label>
                    <div class="col-sm-8">
                      <input type="date" class="form-control" id="FECHA_FIN" name="FECHA_FIN" required placeholder="Escriba la Fecha Fin de su Administraci&oacute;n" maxlength="12" size="12" required>
                    </div>
                 </div>
               <div class="form-group row">
                    <label for="DEPTO" class="col-sm-2 col-form-label">Departamento:</label>
                    <div class="col-sm-8">
                    <select class="form-control" id="DEPTO" name="DEPTO" required placeholder="Indicar el Departamento">
                      <option value="NA">NA</option>
                      <option value="101">101</option>
                      <option value="102">102</option>
					  <option value="201">201</option>
					  <option value="202">202</option>
					  <option value="301">301</option>
					  <option value="302">302</option>
					  <option value="401">401</option>
					  <option value="402">402</option>
                    </select>
                    </div>
               </div><!--form group row-->				 
                 <div class="form-group row">
                    <label for="COMENTARIOS" class="col-sm-2 col-form-label">Comentarios:</label>
                    <div class="col-sm-8">
                      <input type="text" class="form-control" id="COMENTARIOS" name="COMENTARIOS" placeholder="Escribe Comentarios adicionales del Administrador" maxlength="100" size="100">
                    </div>
                 </div>
                 <button type="reset" class="btn btn-secondary">Limpiar</button>
                 <a href="administradores.php" class="btn btn-info active" role="button">Regresar</a>
                 <button type="submit" class="btn btn-success">Guardar</button>
            </form>

            <?php if ($r_actualizado==1) { ?>
             <div class="alert alert-success alert-dismissible" role="alert">
             <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
             <strong>Exito!</strong> El registro fu&eacute; actualizado correctamente.
             </div>
            <?php $r_actualizado=0; } ?>
            
            <?php
            //echo '<script language="javascript">';
            //echo 'alert("message successfully sent")';
            //echo '</script>';
            ?>
         <hr>
         <br>
         <br>
         </div><!-- row -->
   </div><!-- container -->
</body>
</html>
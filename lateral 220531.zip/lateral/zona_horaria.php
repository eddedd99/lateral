<?php
  //zona horaria
  date_default_timezone_set("America/Mexico_City");
  $fecha_local = new DateTime('now');
  $fecha_local_db=date_format($fecha_local, 'Y-m-d H:i:s');
?>
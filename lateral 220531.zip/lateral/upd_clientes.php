<?php
  require 'database.php';//1
   
  $id = null;
  if (!empty($_GET['id']))
      $id = $_REQUEST['id'];

  $regresar = "Location: clientes.php";
  if ( null==$id )
  header($regresar);

  if (!empty($_POST)) {
  
  $id_error = null;
  
  // keep track post values
  $inputRazonSocial = trim($_POST['inputRazonSocial']);
  $inputNombreContacto = trim($_POST['inputNombreContacto']);
  $inputTelPrincipal = trim($_POST['inputTelPrincipal']);
  $inputTelMovil = trim($_POST['inputTelMovil']);  

  //Validaciones
  $valid = true;

  // update data
  if ($valid) {

   require 'zona_horaria.php';
   
   //Si no hay sesion
   if (!isset($_SESSION["nombre_user_session"]))
     $id_usuario='0';
   else
     $id_usuario=$_SESSION["nombre_user_session"];
   
   //ultimo upd
   $last_id=$id;

   $pdo = Database::connect();
   $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   $sql = "UPDATE CLIENTES " .
          "SET RAZON_SOCIAL=? " .
          ",NOMBRE_CONTACTO=? " .
          ",TEL_MOVIL=? " .
		  ",TEL_PPAL=? " .
          "WHERE ID_CLIENTE = ?";
   
   $q = $pdo->prepare($sql);
   $q->execute(array($inputRazonSocial,$inputNombreContacto,$inputTelMovil,$inputTelPrincipal,$id));
   
   //Inserta en Bitácora
   //$sql = "INSERT INTO proveedores_bitac " .
   //       "(r_lock,id_proveedor,nombre_proveedor,contacto,giro,comentarios,timestamp,id_usuario) values (?, ?, ?, ?, ?, ?, ?, ?)";
   //$q = $pdo->prepare($sql);
   //$q->execute(array('1',$last_id,$nombre_proveedor,$contacto,$giro,$comentarios,$fecha_local_db,$id_usuario));

   Database::disconnect();
   $regresar = "Location: clientes.php";
   header($regresar);
  }
 }
 else {
  $pdo = Database::connect();
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "SELECT" .
         " A.ID_CLIENTE " .
         ",A.RAZON_SOCIAL " .
         ",A.NOMBRE_CONTACTO " .
         ",A.TEL_MOVIL " .
         ",A.TEL_PPAL " .
         "FROM CLIENTES A " .
         "WHERE A.ID_CLIENTE = ? ";

  $q = $pdo->prepare($sql);
  $q->execute(array($id));
  $data = $q->fetch(PDO::FETCH_ASSOC);
  
  // keep track post values
  $id = $data['ID_CLIENTE'];
  $inputRazonSocial = $data['RAZON_SOCIAL'];
  $inputNombreContacto = $data['NOMBRE_CONTACTO'];
  $inputTelMovil = $data['TEL_MOVIL'];
  $inputTelPrincipal = $data['TEL_PPAL'];

  Database::disconnect();
 }
?>

<!DOCTYPE html>
<html lang="es-mx">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Actualizar Cliente</title>
  <!-- Bootstrap core CSS -->
  <!--<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">-->
  <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">-->
  <!-- Custom styles for this template -->
  <!--<link href="css/business-frontpage.css" rel="stylesheet">-->
  
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>

<body>
<br>

<div class="container-fluid">
<?php require 'menu.php'; ?>

<div class="col col-md-10">
  <form action="upd_clientes.php?id=<?php echo $id ?>" method="post">
  <h2>Actualizar Cliente</h2>
  <h5>Actualizar los datos del Cliente</h5>
  <br>

  <!--<div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputIdCliente">Id Cliente</label>
    <input type="text" class="form-control" id="inputIdCliente" name="inputIdCliente" placeholder="inputIdCliente" value="<?php echo !empty($id)?$id:'';?>">
  </div>
  </div>-->
  
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputRazonSocial">Raz&oacute;n Social</label>
    <input type="text" class="form-control" id="inputRazonSocial" name="inputRazonSocial" placeholder="Ingresar Razon Social" value="<?php echo !empty($inputRazonSocial)?$inputRazonSocial:'';?>">
  </div>
  </div>
	
  <div class="form-row">
  <div class="form-group col-md-12">
    <label for="inputNombreContacto">Nombre del Contacto</label>
    <input type="text" class="form-control" id="inputNombreContacto" name="inputNombreContacto" placeholder="Ingresar Nombre Contacto" value="<?php echo !empty($inputNombreContacto)?$inputNombreContacto:'';?>">
  </div>
  </div>
  
  <div class="form-row">
	<div class="form-group col-md-6">
       <label for="inputTelPrincipal">Tel&eacute;fono Principal</label>
       <input type="text" class="form-control" id="inputTelPrincipal" name="inputTelPrincipal" placeholder="Ingresar Tel Principal" value="<?php echo !empty($inputTelPrincipal)?$inputTelPrincipal:'';?>">
    </div>
	<div class="form-group col-md-6">
       <label for="inputTelMovil">Tel&eacute;fono M&oacute;vil</label>
       <input type="text" class="form-control" id="inputTelMovil" name="inputTelMovil" placeholder="Ingresar Tel Movil" value="<?php echo !empty($inputTelMovil)?$inputTelMovil:'';?>">
	</div>
  </div>
    <button type="submit" class="btn btn-primary">Grabar</button>
    <a href="clientes.php" class="btn btn-info">Regresar</a>
  </form>
</div>
</div>
</body>
</html>
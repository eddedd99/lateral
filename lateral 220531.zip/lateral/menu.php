<?php
echo '<div class="col col-md-2">';
						echo '<div class="panel-group" id="accordion">';
						  echo '<div class="panel panel-default">';
							echo '<div class="panel-heading">';
							  echo '<h4 class="panel-title">';
								echo '<a data-toggle="collapse" data-parent="#accordion" href="">Clientes</a>';
							  echo '</h4>';
							echo '</div>';
							echo '<div id="collapse1" class="panel-collapse collapse in">';
								echo '<ul class="list-group">';
									echo '<li class="list-group-item"><a href="new_clientes.php">Alta Clientes</a></li>';
									//echo '<li class="list-group-item"><a href="upd_clientes.php">Actualiza Clientes</a></li>';
									echo '<li class="list-group-item"><a href="clientes.php">Clientes</a></li>';
									echo '<li class="list-group-item"><a href="reportes.php">Reportes</a></li>';
								echo '</ul>';
							echo '</div>';
						  echo '</div>';
						echo '</div>';
echo '</div>';
?>

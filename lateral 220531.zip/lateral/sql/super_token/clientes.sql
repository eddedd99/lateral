-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-05-2022 a las 21:16:10
-- Versión del servidor: 10.4.6-MariaDB
-- Versión de PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `order7`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `R_LOCK` tinyint(1) UNSIGNED NOT NULL COMMENT 'R_Lock',
  `ID_CLIENTE` smallint(5) UNSIGNED NOT NULL COMMENT 'ID del Cliente',
  `ESTATUS` varchar(1) NOT NULL COMMENT 'Estatus A=Activo,I=Inactivo',
  `TIPO` varchar(1) NOT NULL COMMENT 'Tipo Cliente P=Prospecto,V=Vigente',
  `RAZON_SOCIAL` varchar(120) NOT NULL COMMENT 'Razón Social',
  `GIRO` varchar(1) NOT NULL COMMENT 'Giro del Cliente (C=Comercial,I=Industrial,S=Servicios)',
  `FECHA_ALTA` timestamp NULL DEFAULT NULL COMMENT 'Fecha Alta Cliente',
  `RFC` varchar(15) NOT NULL COMMENT 'RFC',
  `CURP` varchar(22) NOT NULL COMMENT 'CURP',
  `BANCA_SPEI` varchar(18) NOT NULL COMMENT 'Cuenta Bancaria SPEI',
  `NOMBRE_CONTACTO` varchar(120) NOT NULL COMMENT 'Nombre de la persona contacto',
  `TEL_PRINCIPAL` varchar(25) NOT NULL COMMENT 'Teléfono Principal',
  `TEL_MOVIL` varchar(25) NOT NULL COMMENT 'Teléfono Móvil',
  `EMAIL` varchar(120) NOT NULL COMMENT 'Email',
  `SITIO_WEB` varchar(120) NOT NULL COMMENT 'Sitio Web',
  `COMO_NOS_CONOCIO` varchar(1) NOT NULL COMMENT 'Como nos conocio I=Internet,R=Referido,P=Prensa,R=Redes Sociales',
  `REFERIDO_POR` varchar(99) NOT NULL COMMENT 'Referido por',
  `DIRECCION` varchar(120) NOT NULL COMMENT 'Direccion',
  `PAIS` varchar(50) NOT NULL COMMENT 'Pais',
  `CP` varchar(99) NOT NULL COMMENT 'Código Postal',
  `ESTADO` varchar(99) NOT NULL COMMENT 'Estado',
  `CIUDAD` varchar(99) NOT NULL COMMENT 'Ciudad',
  `MUNICIPIO` varchar(99) NOT NULL COMMENT 'Municipio',
  `COLONIA` varchar(99) NOT NULL COMMENT 'Colonia',
  `COMENTARIOS` varchar(500) NOT NULL COMMENT 'Comentarios',
  `USUARIO` varchar(12) DEFAULT NULL COMMENT 'Usuario actualiza',
  `FECHA_CREACION` timestamp NULL DEFAULT NULL COMMENT 'Fecha Creación',
  `FECHA_ACTUALIZACION` timestamp NULL DEFAULT current_timestamp() COMMENT 'Fecha Actualización'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`R_LOCK`, `ID_CLIENTE`, `ESTATUS`, `TIPO`, `RAZON_SOCIAL`, `GIRO`, `FECHA_ALTA`, `RFC`, `CURP`, `BANCA_SPEI`, `NOMBRE_CONTACTO`, `TEL_PRINCIPAL`, `TEL_MOVIL`, `EMAIL`, `SITIO_WEB`, `COMO_NOS_CONOCIO`, `REFERIDO_POR`, `DIRECCION`, `PAIS`, `CP`, `ESTADO`, `CIUDAD`, `MUNICIPIO`, `COLONIA`, `COMENTARIOS`, `USUARIO`, `FECHA_CREACION`, `FECHA_ACTUALIZACION`) VALUES
(0, 1, 'I', 'V', 'Grupo Industrial del Norte, S.A. de C.V.', 'I', '2022-05-26 05:00:00', 'GIS130406T21', 'NA', '1234123412341234', 'Ing. Juan Manuel Miranda', '55-3943-2351', '55-3943-2351', 'jmemiranda@giden.com', 'www.giden.com', 'R', 'Lic. Manuel Perea Morales', 'Calle Angostura #1244 Piso 1', 'México', '03210', 'Ciudad de México', 'Ciudad de México', 'Ciudad de México', 'Narvarte Poniente', 'Sin comentarios', 'ECRUCES', '2022-05-26 05:00:00', '2022-05-26 18:04:30'),
(0, 2, 'A', 'V', 'Proveedora de Servicios de Limpieza, S.A. de C.V.', 'S', '2022-05-26 05:00:00', 'PSL180506R29', 'NA', '1234123412341234', 'Sr. Roberto Palazuelos', '5542123441', '5543129210', 'contacto@psl.com', 'www.psl.com', 'R', 'Sr. José González', 'Calle 1ro. de Mayo #1230 Int.201', 'México', '03020', 'Ciudad de México', 'Ciudad de México', 'Ciudad de México', 'Col. Del Valle', 'Cliente de primera vez', 'ECRUCES', '2022-05-26 05:00:00', '2022-05-26 18:20:15');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`ID_CLIENTE`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `ID_CLIENTE` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'ID del Cliente', AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
